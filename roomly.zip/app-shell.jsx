/* global React */


/* ============ Sidebar ============ */
function Sidebar({ route, setRoute }) {
  const nav = [
    {
      group: "Workspace",
      items: [
        { id: "dashboard", label: "ダッシュボード", icon: I.dash },
        { id: "properties", label: "物件", icon: I.building, badge: "32" },
        { id: "tenants", label: "入居者", icon: I.users },
        { id: "contracts", label: "契約", icon: I.contract, badge: "8", badgeKind: "warn" },
      ],
    },
    {
      group: "Operations",
      items: [
        { id: "rent", label: "家賃", icon: I.cash, badge: "3", badgeKind: "danger" },
        { id: "maintenance", label: "修繕", icon: I.wrench, badge: "5" },
        { id: "expenses", label: "経費", icon: I.expense },
        { id: "inquiries", label: "問い合わせ", icon: I.inquiry },
      ],
    },
    {
      group: "Finance",
      items: [
        { id: "owners", label: "オーナー", icon: I.owner },
        { id: "remittances", label: "送金", icon: I.send },
        { id: "reports", label: "レポート", icon: I.chart },
      ],
    },
  ];
  return (
    <aside className="sidebar">
      <div className="sb-brand">
        <span className="sb-brand-mark">R</span>
        <span className="sb-brand-name">Roomly</span>
        <span className="sb-brand-sub">v2</span>
      </div>

      <div className="sb-org">
        <span className="sb-org-avatar">山</span>
        <span className="sb-org-text">
          <span className="sb-org-name">山本不動産</span>
          <span className="sb-org-plan">プロプラン · 280戸</span>
        </span>
      </div>

      <nav className="sb-nav">
        {nav.map((g) => (
          <div key={g.group} className="sb-group">
            <div className="sb-group-title">{g.group}</div>
            {g.items.map((it) => (
              <a
                key={it.id}
                className={`sb-link ${route === it.id ? "is-active" : ""}`}
                onClick={() => setRoute(it.id)}
              >
                <span className="sb-link-icon">{it.icon}</span>
                <span>{it.label}</span>
                {it.badge ? <span className={`sb-badge ${it.badgeKind || ""}`}>{it.badge}</span> : null}
              </a>
            ))}
          </div>
        ))}
        <div className="sb-group">
          <div className="sb-group-title">System</div>
          <a className="sb-link" onClick={() => setRoute("settings")}>
            <span className="sb-link-icon">{I.cog}</span>
            <span>設定</span>
          </a>
        </div>
      </nav>

      <div className="sb-user">
        <span className="sb-user-av">T</span>
        <span className="sb-user-text">
          <span className="sb-user-name">高橋 拓也</span>
          <span className="sb-user-role">管理者</span>
        </span>
      </div>
    </aside>
  );
}

/* ============ Topbar ============ */
function Topbar({ crumbs, theme, setTheme }) {
  return (
    <div className="topbar">
      <div className="crumbs">
        {crumbs.map((c, i) => (
          <React.Fragment key={i}>
            {i > 0 && <span className="sep">/</span>}
            <span className={i === crumbs.length - 1 ? "now" : ""}>{c}</span>
          </React.Fragment>
        ))}
      </div>
      <label className="search">
        <span style={{ color: "var(--ink-3)" }}>{I.search}</span>
        <input placeholder="検索 — 物件、入居者、契約…" />
        <kbd>⌘K</kbd>
      </label>
      <div className="topbar-actions">
        <button className="icon-btn" onClick={() => setTheme(theme === "dark" ? "light" : "dark")} aria-label="theme">
          {theme === "dark" ? I.sun : I.moon}
        </button>
        <button className="icon-btn" aria-label="notifications">
          {I.bell}
          <span className="dot" />
        </button>
      </div>
    </div>
  );
}

/* ============ Page header ============ */
function PageHeader({ eyebrow, title, em, sub, right }) {
  const today = new Date(2026, 4, 11);
  const d = `${today.getFullYear()}年${today.getMonth() + 1}月${today.getDate()}日`;
  return (
    <div className="page-head">
      <div>
        {eyebrow ? <span className="eyebrow">{eyebrow}</span> : null}
        <h1>{title} {em ? <em>{em}</em> : null}</h1>
        {sub ? <p style={{ margin: "10px 0 0", color: "var(--ink-3)", fontSize: 14, maxWidth: "60ch" }}>{sub}</p> : null}
      </div>
      <div className="meta">
        {right || (
          <>
            <span className="date">{d}</span>
            <span>火曜日 · 第19週</span>
          </>
        )}
      </div>
    </div>
  );
}

window.Sidebar = Sidebar;
window.Topbar = Topbar;
window.PageHeader = PageHeader;
