/* global React */


/* ============ Sparkline helper ============ */
function RentChart() {
  const data = [
    ["6月", 92.1], ["7月", 93.4], ["8月", 95.0], ["9月", 94.2], ["10月", 96.1], ["11月", 95.4],
    ["12月", 97.0], ["1月", 96.2], ["2月", 95.1], ["3月", 96.5], ["4月", 95.2], ["5月", 94.0]
  ];
  const W = 720, H = 220;
  const padL = 36, padR = 16, padT = 18, padB = 30;
  const innerW = W - padL - padR, innerH = H - padT - padB;
  const yMin = 88, yMax = 100;
  const x = (i) => padL + (i / (data.length - 1)) * innerW;
  const y = (v) => padT + (1 - (v - yMin) / (yMax - yMin)) * innerH;
  const pts = data.map(([, v], i) => [x(i), y(v)]);
  const path = pts.map((p, i) => (i === 0 ? "M" : "L") + p[0].toFixed(1) + "," + p[1].toFixed(1)).join(" ");
  const areaPath = path + ` L${pts[pts.length-1][0]},${padT+innerH} L${pts[0][0]},${padT+innerH} Z`;
  const yTicks = [88, 92, 96, 100];
  const targetY = y(95);
  return (
    <div className="rent-chart">
      <svg viewBox={`0 0 ${W} ${H}`} width="100%" preserveAspectRatio="none" style={{ display: "block", overflow: "visible" }}>
        {yTicks.map((t) => (
          <g key={t}>
            <line x1={padL} x2={W - padR} y1={y(t)} y2={y(t)} stroke="var(--line)" strokeDasharray={t === 100 ? "0" : "2 4"} />
            <text x={padL - 8} y={y(t) + 4} fontSize="10" fill="var(--ink-3)" fontFamily="var(--font-mono)" textAnchor="end">{t}%</text>
          </g>
        ))}
        <line x1={padL} x2={W - padR} y1={targetY} y2={targetY} stroke="var(--accent)" strokeDasharray="4 4" strokeWidth="1" opacity="0.5" />
        <text x={W - padR} y={targetY - 5} fontSize="10" fill="var(--accent-deep)" fontFamily="var(--font-mono)" textAnchor="end">目標 95%</text>
        <defs>
          <linearGradient id="rcArea" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="var(--accent)" stopOpacity="0.22" />
            <stop offset="100%" stopColor="var(--accent)" stopOpacity="0" />
          </linearGradient>
        </defs>
        <path d={areaPath} fill="url(#rcArea)" />
        <path d={path} fill="none" stroke="var(--accent-deep)" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round" />
        {pts.map((p, i) => {
          const isLast = i === pts.length - 1;
          return (
            <g key={i}>
              {isLast ? (
                <>
                  <circle cx={p[0]} cy={p[1]} r="6" fill="var(--surface)" stroke="var(--ink)" strokeWidth="1.5" />
                  <circle cx={p[0]} cy={p[1]} r="2.5" fill="var(--ink)" />
                </>
              ) : (
                <circle cx={p[0]} cy={p[1]} r="3" fill="var(--surface)" stroke="var(--accent-deep)" strokeWidth="1.3" />
              )}
              <text x={p[0]} y={H - padB + 18} fontSize="10" fill={isLast ? "var(--ink)" : "var(--ink-3)"} fontFamily="var(--font-mono)" textAnchor="middle" fontWeight={isLast ? 600 : 400}>{data[i][0]}</text>
              {isLast ? (
                <text x={p[0]} y={p[1] - 12} fontSize="11" fill="var(--ink)" textAnchor="middle" fontWeight="600">{data[i][1].toFixed(1)}%</text>
              ) : null}
            </g>
          );
        })}
      </svg>
    </div>
  );
}

function Spark({ data, color = "var(--accent)", trend = "up" }) {
  const w = 80, h = 28;
  const max = Math.max(...data), min = Math.min(...data);
  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((d - min) / (max - min || 1)) * (h - 4) - 2;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(" ");
  return (
    <svg viewBox={`0 0 ${w} ${h}`} width={w} height={h}>
      <polyline points={pts} fill="none" stroke={color} strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round" />
    </svg>
  );
}

/* ============ Dashboard ============ */
function Dashboard() {
  const overdue = [
    { who: "鈴木 花", room: "ヴェルデ三軒茶屋 203", month: "2026/05", amt: 80000, days: 12 },
    { who: "中野 慎一", room: "コーポ恵比寿 101", month: "2026/05", amt: 72000, days: 7 },
    { who: "小林 美咲", room: "メゾン代官山 305", month: "2026/05", amt: 95000, days: 4 },
  ];
  const maint = [
    { title: "給湯器の不調", prop: "グランド青山 1204", prio: "高", state: "対応中" },
    { title: "玄関ドア立て付け", prop: "メゾン代官山 408", prio: "中", state: "見積待ち" },
    { title: "共用部電球切れ", prop: "ヴェルデ三軒茶屋 共用", prio: "低", state: "完了報告待ち" },
    { title: "水漏れ調査", prop: "コーポ恵比寿 203", prio: "高", state: "対応中" },
  ];
  const expiring = [
    { who: "佐藤 美咲", room: "グランド青山 402", end: "2026/06/30", type: "普通借" },
    { who: "山下 健", room: "ヴェルデ三軒茶屋 105", end: "2026/07/14", type: "定期借" },
    { who: "渡辺 美里", room: "メゾン代官山 201", end: "2026/08/03", type: "普通借" },
  ];
  return (
    <>
      <PageHeader
        eyebrow="Dashboard"
        title="本日の"
        em="管理状況"
        right={
          <>
            <span className="date">5月11日</span>
            <span>火曜日 · 第19週</span>
          </>
        }
      />

      {/* KPI row */}
      <div className="kpi-grid">
        <div className="kpi">
          <div className="kpi-label">管理戸数</div>
          <div className="kpi-value"><span className="num">427</span><span className="unit">戸 / 32棟</span></div>
          <div className="kpi-delta"><span className="pill">+3</span>今月の純増</div>
          <Spark data={[400, 405, 410, 412, 418, 422, 427]} />
          <div className="kpi-spark" />
        </div>
        <div className="kpi">
          <div className="kpi-label">入居率</div>
          <div className="kpi-value"><span className="num">96.4</span><span className="unit">%</span></div>
          <div className="kpi-delta"><span className="pill">+2.1pt</span>前月比</div>
          <div className="kpi-spark"><Spark data={[91, 92, 94, 93, 95, 96, 96.4]} /></div>
        </div>
        <div className="kpi">
          <div className="kpi-label">家賃回収率</div>
          <div className="kpi-value"><span className="num">94</span><span className="unit">%</span></div>
          <div className="kpi-delta"><span className="pill down">−1.2pt</span>滞納3件</div>
          <div className="kpi-spark"><Spark data={[97, 95, 96, 94, 95, 95, 94]} color="var(--danger)" /></div>
        </div>
        <div className="kpi">
          <div className="kpi-label">月次手数料</div>
          <div className="kpi-value">
            <span className="num">¥1,820,000</span>
          </div>
          <div className="kpi-delta"><span className="pill">+4.5%</span>前年比</div>
          <div className="kpi-spark"><Spark data={[1.6, 1.65, 1.7, 1.72, 1.75, 1.78, 1.82]} /></div>
        </div>
      </div>

      {/* Alert strip */}
      <div className="alert-strip">
        <div className="alert">
          <div className="alert-icon danger">{I.cash}</div>
          <div>
            <div className="alert-label">滞納</div>
            <div className="alert-value">3<span style={{ fontSize: 13, color: "var(--ink-3)", marginLeft: 4 }}>件</span></div>
          </div>
          <div className="amt">¥247,000</div>
        </div>
        <div className="alert">
          <div className="alert-icon warn">{I.wrench}</div>
          <div>
            <div className="alert-label">未対応修繕</div>
            <div className="alert-value">5<span style={{ fontSize: 13, color: "var(--ink-3)", marginLeft: 4 }}>件</span></div>
          </div>
          <div className="amt">対応待ち</div>
        </div>
        <div className="alert">
          <div className="alert-icon info">{I.contract}</div>
          <div>
            <div className="alert-label">契約満了間近</div>
            <div className="alert-value">8<span style={{ fontSize: 13, color: "var(--ink-3)", marginLeft: 4 }}>件</span></div>
          </div>
          <div className="amt">3ヶ月以内</div>
        </div>
      </div>

      {/* Two columns: trend + drawer */}
      <div className="cols-2" style={{ marginBottom: 16 }}>
        <div className="section">
          <div className="section-head-bar">
            <h2>家賃回収率 <span className="serif-i" style={{ color: "var(--ink-3)", fontSize: 14, marginLeft: 6 }}>月次推移</span></h2>
            <div className="right">
              <span className="badge neutral mono">直近12ヶ月</span>
              <button className="btn btn-ghost btn-sm">{I.download} CSV</button>
            </div>
          </div>
          <div className="section-body">
            <RentChart />
          </div>
        </div>

        <div className="drawer">
          <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 18 }}>
            <h3>5月の収支</h3>
            <span className="badge accent mono">確定前</span>
          </div>
          <div className="row"><span className="k">家賃収入</span><span className="v">¥35,820,000</span></div>
          <div className="row"><span className="k">共益費・駐車場</span><span className="v">¥2,140,000</span></div>
          <div className="row"><span className="k">管理手数料 (5%)</span><span className="v">¥1,898,000</span></div>
          <div className="row"><span className="k">修繕経費</span><span className="v" style={{ color: "var(--danger)" }}>−¥482,300</span></div>
          <div style={{ marginTop: 14, padding: "16px 0 0", borderTop: "1px solid var(--line)", display: "flex", justifyContent: "space-between", alignItems: "baseline" }}>
            <span style={{ fontSize: 13, color: "var(--ink-3)" }}>送金額 合計</span>
            <span style={{ fontSize: 28, fontWeight: 600, color: "var(--accent-deep)", letterSpacing: "-0.02em", fontVariantNumeric: "tabular-nums" }}>¥28,477,500</span>
          </div>
          <div style={{ display: "flex", gap: 8, marginTop: 18 }}>
            <button className="btn btn-ghost btn-sm" style={{ flex: 1 }}>明細を確認</button>
            <button className="btn btn-accent btn-sm" style={{ flex: 1 }}>送金を確定 {I.arrow}</button>
          </div>
        </div>
      </div>

      {/* Pipeline */}
      <div className="section" style={{ marginBottom: 16 }}>
        <div className="section-head-bar">
          <h2>退去・空室 <span className="serif-i" style={{ color: "var(--ink-3)", fontSize: 14, marginLeft: 6 }}>パイプライン</span></h2>
          <div className="right">
            <button className="btn btn-ghost btn-sm">{I.plus} 募集を追加</button>
          </div>
        </div>
        <div className="section-body flush">
          <div className="pipeline">
            <div className="pipeline-col">
              <div className="pipeline-head">
                <span className="tag" style={{ background: "var(--warn-tint)", color: "var(--warn)" }}>退去予定</span>
                <span className="count">3</span>
              </div>
              {[["佐藤 美咲", "グランド青山 402", "6/30", 50], ["田村 健太", "コーポ恵比寿 305", "7/14", 64], ["林 麻衣", "ヴェルデ三軒茶屋 208", "7/31", 81]].map(([w, p, d, days]) => (
                <div key={w} className="pipeline-item">
                  <span className="who">{w}</span>
                  <span className="what">{p}</span>
                  <span className="when" style={{ color: days <= 30 ? "var(--danger)" : "var(--warn)" }}>あと{days}日 · {d}</span>
                </div>
              ))}
            </div>
            <div className="pipeline-col">
              <div className="pipeline-head">
                <span className="tag" style={{ background: "var(--info-tint)", color: "var(--info)" }}>原状回復中</span>
                <span className="count">2</span>
              </div>
              {[["メゾン代官山 305", "¥95,000", "2026/05/03〜"], ["コーポ恵比寿 101", "¥72,000", "2026/04/28〜"]].map(([p, r, s]) => (
                <div key={p} className="pipeline-item">
                  <span className="who">{p}</span>
                  <span className="what">{r}/月 · {s}</span>
                  <span className="when" style={{ color: "var(--ink-2)" }}>クロス張替 · 清掃</span>
                </div>
              ))}
            </div>
            <div className="pipeline-col">
              <div className="pipeline-head">
                <span className="tag" style={{ background: "var(--accent-tint)", color: "var(--accent-deep)" }}>募集中</span>
                <span className="count">4</span>
              </div>
              {[["ヴェルデ三軒茶屋 105", "¥74,000", 32], ["ヴェルデ三軒茶屋 308", "¥78,000", 8], ["メゾン代官山 201", "¥110,000", 14], ["グランド青山 803", "¥165,000", 3]].map(([p, r, days]) => (
                <div key={p} className="pipeline-item">
                  <span className="who">{p}</span>
                  <span className="what">{r}/月</span>
                  <span className="when" style={{ color: "var(--accent-deep)" }}>掲載 {days}日 · 内見3件</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Bottom: 2 tables */}
      <div className="cols-2-eq">
        <div className="section">
          <div className="section-head-bar">
            <h2>滞納一覧</h2>
            <div className="right">
              <span className="badge danger mono">3件 / ¥247,000</span>
            </div>
          </div>
          <div className="section-body flush">
            <table className="tbl">
              <thead>
                <tr>
                  <th>入居者</th>
                  <th>対象月</th>
                  <th style={{ textAlign: "right" }}>金額</th>
                  <th>状態</th>
                </tr>
              </thead>
              <tbody>
                {overdue.map((r) => (
                  <tr key={r.who} className="row-hover">
                    <td>
                      <div className="strong">{r.who}</div>
                      <div style={{ fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>{r.room}</div>
                    </td>
                    <td className="mono" style={{ fontSize: 12, color: "var(--ink-2)" }}>{r.month}</td>
                    <td className="num">¥{r.amt.toLocaleString()}</td>
                    <td><span className="badge danger"><span className="dot" />{r.days}日滞納</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        <div className="section">
          <div className="section-head-bar">
            <h2>修繕対応中</h2>
            <div className="right">
              <span className="badge warn mono">4件</span>
            </div>
          </div>
          <div className="section-body flush">
            <table className="tbl">
              <thead>
                <tr><th>件名</th><th>物件</th><th>優先度</th><th>状態</th></tr>
              </thead>
              <tbody>
                {maint.map((m) => (
                  <tr key={m.title} className="row-hover">
                    <td className="strong">{m.title}</td>
                    <td style={{ fontSize: 12, color: "var(--ink-3)" }}>{m.prop}</td>
                    <td><span className={`badge ${m.prio === "高" ? "danger" : m.prio === "中" ? "warn" : "neutral"}`}>{m.prio}</span></td>
                    <td><span className="badge accent"><span className="dot" />{m.state}</span></td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </>
  );
}

window.Dashboard = Dashboard;
window.Spark = Spark;
