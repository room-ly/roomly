/* global React */

/* ============ Properties ============ */
function BuildingIllustration({ seed, tone }) {
  // Deterministic pseudo-random from seed
  const s = String(seed || "x");
  let h = 1; for (let i = 0; i < s.length; i++) h = (h * 31 + s.charCodeAt(i)) | 0;
  if (h === 0) h = 1;
  const rand = (n) => { h = Math.abs((h * 9301 + 49297) % 233280); return h / 233280 * n; };
  const floors = 4 + Math.floor(rand(4)); // 4-7
  const cols = 3 + Math.floor(rand(3)); // 3-5
  const toneColors = {
    sage: ["#c8d4cb", "#94aa9b", "#6a8273"],
    warm: ["#e6d4c0", "#caa580", "#9a7a55"],
    olive: ["#c9c4ad", "#9a9376", "#6e6849"],
    sand: ["#e1d4ba", "#b8a37a", "#857354"],
    blue: ["#c0c8d4", "#8e9bb0", "#5d6a82"],
    clay: ["#d8bfb0", "#b58e7a", "#7e5a47"],
  }[tone] || ["#d0cabc", "#9c9683", "#67614f"];
  const [light, mid, dark] = toneColors;
  const W = 200, H = 160;
  const bldgW = 150, bldgH = 110;
  const x0 = (W - bldgW) / 2, y0 = H - bldgH - 8;
  const winW = (bldgW - 24) / cols * 0.55;
  const winH = (bldgH - 18) / floors * 0.5;
  const gapX = (bldgW - 24 - winW * cols) / (cols - 1);
  const gapY = (bldgH - 18 - winH * floors) / (floors);
  const wins = [];
  for (let f = 0; f < floors; f++) {
    for (let c = 0; c < cols; c++) {
      const lit = rand(1) > 0.55;
      wins.push({
        x: x0 + 12 + c * (winW + gapX),
        y: y0 + 12 + f * (winH + gapY),
        lit,
      });
    }
  }
  return (
    <svg className="bldg" viewBox={`0 0 ${W} ${H}`} preserveAspectRatio="xMidYMax meet" fill="none">
      {/* sky/ground subtle */}
      <rect x="0" y={H - 8} width={W} height="8" fill={dark} opacity="0.25" />
      {/* building body */}
      <rect x={x0} y={y0} width={bldgW} height={bldgH} fill={light} />
      {/* roof line */}
      <rect x={x0 - 4} y={y0 - 4} width={bldgW + 8} height="4" fill={mid} />
      {/* entrance */}
      <rect x={x0 + bldgW / 2 - 10} y={y0 + bldgH - 18} width="20" height="18" fill={dark} opacity="0.7" />
      {/* windows */}
      {wins.map((w, i) => (
        <rect key={i} x={w.x} y={w.y} width={winW} height={winH}
          fill={w.lit ? "#fbf6e6" : dark}
          opacity={w.lit ? 0.95 : 0.55}
          rx="1" />
      ))}
    </svg>
  );
}

function OccRing({ pct }) {
  const full = pct >= 100;
  const color = full ? "var(--accent-deep)" : pct >= 95 ? "var(--accent-deep)" : pct >= 90 ? "var(--accent)" : "var(--warn)";
  return (
    <div className="occ-chip">
      <div className="occ-chip-head">
        <span className="occ-chip-tag">入居率</span>
        <span className="occ-chip-val" style={{ color }}><b>{pct}</b><small>%</small></span>
      </div>
      <div className="occ-chip-bar">
        <div className="occ-chip-bar-fill" style={{ width: `${pct}%`, background: color }} />
      </div>
    </div>
  );
}

function PropertiesPage() {
  const rows = [
    { name: "グランド青山", addr: "東京都港区南青山4-12-7", units: 24, occ: 96, rent: "¥3,840,000", owner: "森本 哲也", tone: "sage" },
    { name: "メゾン代官山", addr: "東京都渋谷区代官山町8-1", units: 18, occ: 94, rent: "¥2,210,000", owner: "藤村 一郎", tone: "warm" },
    { name: "ヴェルデ三軒茶屋", addr: "東京都世田谷区三軒茶屋2-9-4", units: 32, occ: 100, rent: "¥2,780,000", owner: "山田 由佳", tone: "olive" },
    { name: "コーポ恵比寿", addr: "東京都渋谷区恵比寿西1-4-2", units: 14, occ: 92, rent: "¥1,420,000", owner: "森本 哲也", tone: "sand" },
    { name: "サンライト中目黒", addr: "東京都目黒区上目黒3-1-15", units: 22, occ: 100, rent: "¥3,050,000", owner: "高橋 美津子", tone: "blue" },
    { name: "リバーサイド広尾", addr: "東京都渋谷区広尾2-8-3", units: 16, occ: 88, rent: "¥2,960,000", owner: "藤村 一郎", tone: "clay" },
  ];
  return (
    <>
      <PageHeader
        eyebrow="Properties"
        title="物件"
        em="32棟"
        sub="管理中の物件を一覧。物件カードから入居状況・収支・修繕履歴をまとめて確認できます。"
      />
      <div className="toolbar">
        <div className="tb-tabs">
          <span className="tb-tab is-active">すべて<span className="c">32</span></span>
          <span className="tb-tab">区分マンション<span className="c">21</span></span>
          <span className="tb-tab">一棟<span className="c">9</span></span>
          <span className="tb-tab">戸建<span className="c">2</span></span>
        </div>
        <div className="tb-actions">
          <button className="btn btn-ghost btn-sm">{I.filter} フィルタ</button>
          <button className="btn btn-ghost btn-sm">{I.sort} 並び替え</button>
          <button className="btn btn-accent btn-sm">{I.plus} 物件を追加</button>
        </div>
      </div>

      <div className="prop-grid">
        {rows.map((r) => (
          <div key={r.name} className="prop-card">
            <div className={`prop-thumb tone-${r.tone}`}>
              <BuildingIllustration seed={r.name} tone={r.tone} />
            </div>
            <div className="prop-body">
              <div className="prop-title-row">
                <h3>{r.name}</h3>
                <OccRing pct={r.occ} />
              </div>
              <p className="prop-addr">{r.addr}</p>
              <div className="prop-meta">
                <span className="prop-meta-item"><b>{r.units}</b>戸</span>
                <span className="prop-meta-sep">·</span>
                <span className="prop-meta-item">{r.rent}<small>/月</small></span>
              </div>
              <div className="prop-owner">
                <span className="prop-owner-av">{r.owner.slice(0,1)}</span>
                <span className="prop-owner-name">{r.owner}</span>
                <span className="prop-owner-label">家主</span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </>
  );
}

/* ============ Rent ledger ============ */
function RentPage() {
  const rows = [
    { who: "佐藤 美咲", room: "グランド青山 402", amt: 145000, due: "5/01", paid: "5/01", state: "paid" },
    { who: "鈴木 花", room: "ヴェルデ三軒茶屋 203", amt: 80000, due: "5/01", paid: "—", state: "overdue", days: 12 },
    { who: "中野 慎一", room: "コーポ恵比寿 101", amt: 72000, due: "5/01", paid: "—", state: "overdue", days: 7 },
    { who: "山下 健", room: "ヴェルデ三軒茶屋 105", amt: 74000, due: "5/01", paid: "5/02", state: "paid" },
    { who: "渡辺 美里", room: "メゾン代官山 201", amt: 110000, due: "5/01", paid: "5/01", state: "paid" },
    { who: "小林 美咲", room: "メゾン代官山 305", amt: 95000, due: "5/01", paid: "—", state: "overdue", days: 4 },
    { who: "高山 圭吾", room: "サンライト中目黒 506", amt: 138000, due: "5/01", paid: "5/03", state: "paid" },
    { who: "井上 詩織", room: "グランド青山 803", amt: 165000, due: "5/05", paid: "—", state: "pending" },
    { who: "森田 久美", room: "リバーサイド広尾 401", amt: 184000, due: "5/01", paid: "5/01", state: "paid" },
    { who: "藤井 雄太", room: "ヴェルデ三軒茶屋 308", amt: 78000, due: "5/05", paid: "—", state: "pending" },
  ];
  const fmt = (n) => "¥" + n.toLocaleString();
  return (
    <>
      <PageHeader
        eyebrow="Rent ledger"
        title="家賃"
        em="管理"
        sub="5月分 — 入金状況の確認、督促状の送付、入金消し込みが行えます。"
      />

      <div className="cols-summary">
        <div className="sum-card">
          <span className="sum-label">5月請求額</span>
          <span className="sum-value serif-i">¥37,960,000</span>
          <span className="sum-foot mono">427件</span>
        </div>
        <div className="sum-card">
          <span className="sum-label">入金済</span>
          <span className="sum-value serif-i" style={{ color: "var(--accent-deep)" }}>¥35,713,000</span>
          <span className="sum-foot mono">94% · 401件</span>
        </div>
        <div className="sum-card">
          <span className="sum-label">未収・滞納</span>
          <span className="sum-value serif-i" style={{ color: "var(--danger)" }}>¥247,000</span>
          <span className="sum-foot mono">3件</span>
        </div>
        <div className="sum-card">
          <span className="sum-label">引落予定</span>
          <span className="sum-value serif-i">¥2,000,000</span>
          <span className="sum-foot mono">5/27 振替</span>
        </div>
      </div>

      <div className="toolbar">
        <div className="tb-tabs">
          <span className="tb-tab is-active">すべて<span className="c">427</span></span>
          <span className="tb-tab">入金済<span className="c">401</span></span>
          <span className="tb-tab">未入金<span className="c">23</span></span>
          <span className="tb-tab danger">滞納<span className="c">3</span></span>
        </div>
        <div className="tb-actions">
          <span className="mono" style={{ fontSize: 12, color: "var(--ink-3)" }}>2026年5月</span>
          <button className="btn btn-ghost btn-sm">{I.download} 書出</button>
          <button className="btn btn-accent btn-sm">督促状を送付 {I.arrow}</button>
        </div>
      </div>

      <div className="section">
        <div className="section-body flush">
          <table className="tbl">
            <thead>
              <tr>
                <th style={{ width: 28 }}><input type="checkbox" /></th>
                <th>入居者 / 部屋</th>
                <th>請求日</th>
                <th>入金日</th>
                <th style={{ textAlign: "right" }}>金額</th>
                <th>状態</th>
                <th style={{ width: 80 }}></th>
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.who} className="row-hover">
                  <td><input type="checkbox" /></td>
                  <td>
                    <div className="strong">{r.who}</div>
                    <div style={{ fontSize: 11, color: "var(--ink-3)", marginTop: 2 }}>{r.room}</div>
                  </td>
                  <td className="mono" style={{ fontSize: 12, color: "var(--ink-2)" }}>{r.due}</td>
                  <td className="mono" style={{ fontSize: 12, color: r.paid === "—" ? "var(--ink-4)" : "var(--ink-2)" }}>{r.paid}</td>
                  <td className="num">{fmt(r.amt)}</td>
                  <td>
                    {r.state === "paid" && <span className="badge ok"><span className="dot" />入金済</span>}
                    {r.state === "pending" && <span className="badge neutral"><span className="dot" />引落予定</span>}
                    {r.state === "overdue" && <span className="badge danger"><span className="dot" />{r.days}日滞納</span>}
                  </td>
                  <td><button className="btn btn-ghost btn-sm" style={{ padding: "4px 10px" }}>詳細</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

/* ============ Maintenance kanban ============ */
function MaintenancePage() {
  const cols = [
    {
      label: "新規受付", tone: "info", items: [
        { title: "ベランダ手すり緩み", prop: "サンライト中目黒 304", who: "石川 さん", at: "5/10 14:22", prio: "中" },
        { title: "排水詰まり", prop: "リバーサイド広尾 201", who: "佐々木 さん", at: "5/10 09:48", prio: "高" },
      ]
    },
    {
      label: "見積待ち", tone: "warn", items: [
        { title: "玄関ドア立て付け", prop: "メゾン代官山 408", who: "山本工務店", at: "5/08", prio: "中" },
        { title: "クロス張替 (退去後)", prop: "コーポ恵比寿 101", who: "AAA内装", at: "5/06", prio: "中" },
      ]
    },
    {
      label: "対応中", tone: "accent", items: [
        { title: "給湯器の不調", prop: "グランド青山 1204", who: "東京住設", at: "5/09", prio: "高" },
        { title: "水漏れ調査", prop: "コーポ恵比寿 203", who: "東京住設", at: "5/09", prio: "高" },
        { title: "エアコン異音", prop: "ヴェルデ三軒茶屋 412", who: "AC東京", at: "5/07", prio: "低" },
      ]
    },
    {
      label: "完了", tone: "ok", items: [
        { title: "共用部電球切れ", prop: "ヴェルデ三軒茶屋 共用", who: "自社対応", at: "5/05", prio: "低" },
        { title: "ポスト鍵交換", prop: "メゾン代官山 305", who: "鍵屋A", at: "5/04", prio: "低" },
      ]
    },
  ];
  return (
    <>
      <PageHeader
        eyebrow="Maintenance"
        title="修繕"
        em="対応"
        sub="入居者からの依頼、見積、業者手配、完了報告までを一画面で管理します。"
      />
      <div className="toolbar">
        <div className="tb-tabs">
          <span className="tb-tab is-active">かんばん</span>
          <span className="tb-tab">一覧</span>
          <span className="tb-tab">カレンダー</span>
        </div>
        <div className="tb-actions">
          <button className="btn btn-ghost btn-sm">{I.filter} 物件</button>
          <button className="btn btn-accent btn-sm">{I.plus} 修繕を起票</button>
        </div>
      </div>

      <div className="kanban">
        {cols.map((c) => (
          <div className="kb-col" key={c.label}>
            <div className="kb-col-head">
              <span className={`badge ${c.tone}`}>{c.label}</span>
              <span className="mono" style={{ fontSize: 11, color: "var(--ink-4)" }}>{c.items.length}</span>
            </div>
            {c.items.map((it, i) => (
              <div className="kb-card" key={i}>
                <div className="kb-card-prio">
                  <span className={`badge ${it.prio === "高" ? "danger" : it.prio === "中" ? "warn" : "neutral"}`} style={{ padding: "2px 6px" }}>{it.prio}</span>
                  <span className="mono" style={{ fontSize: 10, color: "var(--ink-4)" }}>#{1000 + i}</span>
                </div>
                <div className="kb-card-title">{it.title}</div>
                <div className="kb-card-prop">{it.prop}</div>
                <div className="kb-card-foot">
                  <span>{it.who}</span>
                  <span className="mono">{it.at}</span>
                </div>
              </div>
            ))}
            <button className="kb-add">{I.plus} 追加</button>
          </div>
        ))}
      </div>
    </>
  );
}

/* ============ Remittances ============ */
function RemittancesPage() {
  const owners = [
    { name: "森本 哲也", props: ["グランド青山", "コーポ恵比寿"], gross: 5260000, fee: 263000, expense: 184000, net: 4813000, state: "ready" },
    { name: "藤村 一郎", props: ["メゾン代官山", "リバーサイド広尾"], gross: 5170000, fee: 258500, expense: 92300, net: 4819200, state: "ready" },
    { name: "山田 由佳", props: ["ヴェルデ三軒茶屋"], gross: 2780000, fee: 139000, expense: 56000, net: 2585000, state: "ready" },
    { name: "高橋 美津子", props: ["サンライト中目黒"], gross: 3050000, fee: 152500, expense: 38000, net: 2859500, state: "draft" },
    { name: "片岡 健一", props: ["ヴィラ表参道"], gross: 1820000, fee: 91000, expense: 122000, net: 1607000, state: "draft" },
  ];
  const fmt = (n) => "¥" + n.toLocaleString();
  return (
    <>
      <PageHeader
        eyebrow="Remittances"
        title="オーナー"
        em="送金"
        sub="5月度 — 全12オーナー · 確定後ワンクリックで一括送金 (Zengin) ファイルを生成します。"
      />

      <div className="cols-summary">
        <div className="sum-card">
          <span className="sum-label">家賃収入</span>
          <span className="sum-value serif-i">¥35,820,000</span>
        </div>
        <div className="sum-card">
          <span className="sum-label">手数料 (5%)</span>
          <span className="sum-value serif-i">¥1,898,000</span>
        </div>
        <div className="sum-card">
          <span className="sum-label">経費控除</span>
          <span className="sum-value serif-i">¥482,300</span>
        </div>
        <div className="sum-card sum-card-em">
          <span className="sum-label">送金合計</span>
          <span className="sum-value serif-i" style={{ color: "var(--accent-deep)" }}>¥28,477,500</span>
          <span className="sum-foot mono">12オーナー / 5月27日 振込</span>
        </div>
      </div>

      <div className="toolbar">
        <div className="tb-tabs">
          <span className="tb-tab is-active">送金一覧</span>
          <span className="tb-tab">FBデータ書出</span>
          <span className="tb-tab">月次報告書</span>
        </div>
        <div className="tb-actions">
          <button className="btn btn-ghost btn-sm">{I.download} PDF</button>
          <button className="btn btn-accent btn-sm">送金を確定 {I.arrow}</button>
        </div>
      </div>

      <div className="section">
        <div className="section-body flush">
          <table className="tbl">
            <thead>
              <tr>
                <th>オーナー</th>
                <th>物件</th>
                <th style={{ textAlign: "right" }}>家賃</th>
                <th style={{ textAlign: "right" }}>手数料</th>
                <th style={{ textAlign: "right" }}>経費</th>
                <th style={{ textAlign: "right" }}>送金額</th>
                <th>状態</th>
              </tr>
            </thead>
            <tbody>
              {owners.map((o) => (
                <tr key={o.name} className="row-hover">
                  <td className="strong">{o.name}</td>
                  <td style={{ fontSize: 12, color: "var(--ink-3)" }}>{o.props.join(" · ")}</td>
                  <td className="num">{fmt(o.gross)}</td>
                  <td className="num" style={{ color: "var(--ink-3)" }}>−{fmt(o.fee)}</td>
                  <td className="num" style={{ color: "var(--ink-3)" }}>−{fmt(o.expense)}</td>
                  <td className="num" style={{ fontSize: 13.5, fontWeight: 600, color: "var(--accent-deep)" }}>{fmt(o.net)}</td>
                  <td>{o.state === "ready" ? <span className="badge accent"><span className="dot" />確定済</span> : <span className="badge neutral"><span className="dot" />下書き</span>}</td>
                </tr>
              ))}
              <tr className="tbl-total">
                <td colSpan="2" className="strong">合計 5オーナー</td>
                <td className="num">{fmt(18080000)}</td>
                <td className="num">−{fmt(904000)}</td>
                <td className="num">−{fmt(492300)}</td>
                <td className="num" style={{ fontSize: 14, fontWeight: 600, color: "var(--accent-deep)" }}>{fmt(16683700)}</td>
                <td></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
    </>
  );
}

window.PropertiesPage = PropertiesPage;
window.RentPage = RentPage;
window.MaintenancePage = MaintenancePage;
window.RemittancesPage = RemittancesPage;
